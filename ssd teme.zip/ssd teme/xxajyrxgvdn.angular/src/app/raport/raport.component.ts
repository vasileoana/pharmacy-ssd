import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-raport',
  templateUrl: './raport.component.html',
  styleUrls: ['./raport.component.css']
})
export class RaportComponent implements OnInit {

  constructor() { }

  cifraAfaceri: number[];
  medici: number [];
  locuitori: number []  ;
  judet: String[] ; 
  chartData;

  displayedColumns: string[] = ['judet', 'numar_locuitori', 'numar_medici', 'cifra_afaceri'];
  dataSource : Object[];

  ngOnInit() {
    this.populareCA();
    this.pupulareMedici();
    this.pupulareLocuitori();
    this.populareJudete();  
    this.dataSource = [];
    for(let i=0; i< this.judet.length; i++){
      this.dataSource.push({
        'judet' : this.judet[i], 'numar_locuitori' : this.locuitori[i], 'numar_medici' : this.medici[i], 'cifra_afaceri':this.cifraAfaceri[i]
      } )
    }
}

  populareCA(){
    this.cifraAfaceri = [4.2622735392,
      3.6982572953,
      5.233475164200001,
      9.7277517319,
      7.9301600977,
      8.9144080723,
      5.412389743599999,
      4.3610088086,
      16.62303032,
      4.9628858811,
      3.5899856303,
      18.4945356878,
      17.1912799255,
      4.8034175828,
      5.1919615262,
      14.9532426391,
      6.4666091274,
      2.2672143287,
      1.0394512686,
      2.5278874469,
      2.1925675962,
      6.471043399,
      0.5385470919000001,
      5.2576570323,
      1.8159093263,
      8.367393072,
      3.2713846872,
      4.306889669499999,
      14.3954911405,
      3.1189246891,
      3.3001826961,
      8.996102732599999,
      14.5248926313,
      3.8309432902,
      10.7498761939,
      2.296153021,
      2.5477809108,
      3.0428120329,
      4.635381869800001]
  }

  pupulareMedici(){
    this.medici = [7.07,
      11.05,
      14.18,
      11.1,
      18.99,
      4.43,
      6.06,
      5.36,
      16.22,
      6.25,
      5.54,
      37.43,
      19.85,
      4.5599,
      5.85,
      27.26,
      9.68,
      3.25,
      7.29,
      5.08,
      11.26,
      3.26,
      6.67,
      8.65,
      4.87,
      22.62,
      8.19,
      7.4,
      11.27,
      3.91,
      5.94,
      12.27,
      9.24,
      5.71,
      38.4,
      3.75,
      6.91,
      5.45,
      5.21,
      ]
  }

  pupulareLocuitori(){
      this.locuitori = [3.80976,
        4.73946,
        6.46333,
        7.46566,
        6.19102,
        3.29188,
        4.55973,
        3.56196,
        6.30807,
        4.7881099,
        3.28047,
        7.21955,
        7.69768,
        2.28732,
        5.28426,
        7.00117,
        6.31669,
        2.76781,
        3.66261,
        3.33674,
        4.69853,
        2.93658,
        3.90751,
        5.25765,
        2.86678,
        5.95948,
        5.77359,
        4.50094,
        8.09052,
        2.47537,
        3.90639,
        4.642019,
        7.43645,
        3.89433,
        7.42886,
        2.44249,
        4.03171,
        4.79815,
        3.91169
      ];
  }

  populareJudete(){
    this.judet = ['ALBA',
      'ARAD',
      'ARGES',
      'BACAU',
      'BIHOR',
      'BISTRITA-NASAUD',
      'BOTOSANI',
      'BRAILA',
      'BRASOV',
      'BUZAU',
      'CARAS-SEVERIN',
      'CLUJ',
      'CONSTANTA',
      'COVASNA',
      'DAMBOVITA',
      'DOLJ',
      'GALATI',
      'GIURGIU',
      'GORJ',
      'HARGHITA',
      'HUNEDOARA',
      'IALOMITA',
      'ILFOV',
      'MARAMURES',
      'MEHEDINTI',
      'MURES',
      'NEAMT',
      'OLT',
      'PRAHOVA',
      'SALAJ',
      'SATU MARE',
      'SIBIU',
      'SUCEAVA',
      'TELEORMAN',
      'TIMIS',
      'TULCEA',
      'VALCEA',
      'VASLUI',
      'VRANCEA'
      ]
  }



  /**
 * Define data for each year
 */


/**
 * Create the chart
 */



}