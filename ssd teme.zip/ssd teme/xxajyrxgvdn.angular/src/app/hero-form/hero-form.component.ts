import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-hero-form',
  templateUrl: './hero-form.component.html',
  styleUrls: ['./hero-form.component.css']
})
export class HeroFormComponent implements OnInit{

   locuitori: String = ' ';
   medici: String = ' ';
   cifraAfaceri : Number ;
   isVisible : boolean;
   isRaportVisible: boolean;
  constructor() {}

  ngOnInit(){
    this.isVisible = false;
  }

  onSubmit() {  
    this.isVisible = true;
    this.calculeaza();
    this.isRaportVisible = false;
  }

  calculeaza(){
    this.cifraAfaceri = Number ((-2.9971+ 1.5825*(Number(this.locuitori)/100)  + 0.1695* Number(this.medici)).toFixed(5));
  }

  clear() {
    this.medici = '';
    this.locuitori = '';
    this.isVisible = false;
  }

  raport() {
    if(this.isRaportVisible)
    this.isRaportVisible = false;
    else
    this.isRaportVisible = true;
  }
}



/*
Copyright 2017-2018 Google Inc. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/